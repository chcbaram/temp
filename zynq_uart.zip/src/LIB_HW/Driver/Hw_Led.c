//----------------------------------------------------------------------------
//    프로그램명 	: LED 관련 함수
//
//    만든이     	:
//
//    날  짜     	:
//    
//    최종 수정  	:
//
//    MPU_Type		:
//
//    파일명     	: Hw_Led.c
//----------------------------------------------------------------------------


//----- 헤더파일 열기
//
#define  HW_LED_LOCAL


#include "Hw_Led.h"


#define LED 		0x01
#define LED_DELAY   0x1000000
#define LED_CHANNEL 1



//-- 내부 변수
//
XGpio Gpio;





/*---------------------------------------------------------------------------
     TITLE   : Hw_Led_Init
     WORK    : 
     ARG     : void
     RET     : void
---------------------------------------------------------------------------*/
void Hw_Led_Init( void )
{
	int Status;


	Status = XGpio_Initialize(&Gpio, XPAR_GPIO_0_DEVICE_ID);
	if (Status != XST_SUCCESS)
	{
		//return XST_FAILURE;
	}

	//-- 방향 출력으로 설정
	//
	XGpio_SetDataDirection(&Gpio, LED_CHANNEL, ~LED);


	Hw_Led_Off(0);
	Hw_Led_Off(1);	
}





/*---------------------------------------------------------------------------
     TITLE   : Hw_Led_On
     WORK    :
     ARG     : void
     RET     : void
---------------------------------------------------------------------------*/
void Hw_Led_On( u8 Ch )
{	
	u32 Data;

	switch( Ch )
	{
		case 0:
			Data = XGpio_DiscreteRead(&Gpio, LED_CHANNEL);
			CLR_BIT( Data, 0 );
			XGpio_DiscreteWrite(&Gpio, LED_CHANNEL, Data);
			break;

		case 1:
			break;
	}
}





/*---------------------------------------------------------------------------
     TITLE   : Hw_Led_Off
     WORK    :
     ARG     : void
     RET     : void
---------------------------------------------------------------------------*/
void Hw_Led_Off( u8 Ch )
{
	u32 Data;

	switch( Ch )
	{
		case 0:
			Data = XGpio_DiscreteRead(&Gpio, LED_CHANNEL);
			SET_BIT( Data, 0 );
			XGpio_DiscreteWrite(&Gpio, LED_CHANNEL, Data);
			break;

		case 1:
			break;
	}
}





/*---------------------------------------------------------------------------
     TITLE   : Hw_Led_Toggle
     WORK    :
     ARG     : void
     RET     : void
---------------------------------------------------------------------------*/
void Hw_Led_Toggle( u8 Ch )
{
	u32 Data;


	switch( Ch )
	{
		case 0:
			Data = XGpio_DiscreteRead(&Gpio, LED_CHANNEL);
			TGL_BIT( Data, 0 );
			XGpio_DiscreteWrite(&Gpio, LED_CHANNEL, Data);
			break;

		case 1:
			break;
	}
}





/*---------------------------------------------------------------------------
     TITLE   : Hw_Led_Wait
     WORK    : 
     ARG     : void
     RET     : void
---------------------------------------------------------------------------*/
void Hw_Led_Wait( u32 delay )
{
    volatile u32 i;
    for ( i = 0 ; i < delay ; i++ ){ };
}



















 
