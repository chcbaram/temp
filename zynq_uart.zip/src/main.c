//----------------------------------------------------------------------------
//    프로그램명 	: Main
//
//    만든이     	: Cho Han Cheol (Baram)
//
//    날  짜     	: 2013. 8.20.
//
//    최종 수정  	:
//
//    MPU_Type	:
//
//    파일명     	: Main.c
//----------------------------------------------------------------------------
/*
*/
//-----
//
#define  MAIN_LOCAL

#include "Main.h"



void Main_Init( void );


void Uart1_ISR(char Ch)
{
	Lb_printf("Received : %c\n", Ch);
}



int main(void)
{
	vu32 Delay;
	u32 i;

	Main_Init();

	IP_PWM_mWriteReg(XPAR_IP_PWM_0_S00_AXI_BASEADDR, 0*4, 1);
	IP_PWM_mWriteReg(XPAR_IP_PWM_0_S00_AXI_BASEADDR, 1*4, 0);
	IP_PWM_mWriteReg(XPAR_IP_PWM_0_S00_AXI_BASEADDR, 2*4, 100);


	while (1)
	{
		Hw_Led_Toggle(0);

		//for (Delay = 0; Delay < 0x1000000; Delay++);

		//Lb_printf("Led \n");

		//Hw_Uart_Putch(0, 'A');

		for( i=0; i<=255; i++ )
		{
			IP_PWM_mWriteReg(XPAR_IP_PWM_0_S00_AXI_BASEADDR, 2*4, i);
			for (Delay = 0; Delay < 0x100000; Delay++);
		}

		Lb_printf("Tick\n");

	}

	return XST_SUCCESS;
}





/*---------------------------------------------------------------------------
     TITLE   : Main_Init
     WORK    :
     ARG     : void
     RET     : void
---------------------------------------------------------------------------*/
void Main_Init( void )
{
	Hw_Init();
	Ap_Init();


	Hw_Uart_SetReceiveFuncISR( 0, Uart1_ISR );
}

