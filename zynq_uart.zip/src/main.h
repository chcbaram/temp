//    프로그램명 	: Main 헤더
//
//    만든이     	: 
//
//    날  짜     	:
//    
//    최종 수정  	:
//
//    MPU_Type		:
//
//    파일명     	: Main.h
//----------------------------------------------------------------------------
                                                                                                 
#ifndef __MAIN_H__
#define __MAIN_H__


#ifdef   MAIN_LOCAL
#define  EXT_MAIN_DEF
#else
#define  EXT_MAIN_DEF     extern
#endif



#include "Ap.h"




#endif
